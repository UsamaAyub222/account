<?php
include('conn.php');
include("login_check.php");
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Home</title>
	<?php 
	include('head.php');
	?>
</head>
<body>
	<?php include('menue.php');?>

</body>
</html>